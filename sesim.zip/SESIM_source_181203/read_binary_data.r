##############################################################################
# Program for reading binary data output from SESIM.
# The output consists of the Sdat list containing dataframes idata, hdata and
# mdata holding individual data, household data and macro data.
# Also, ASCII output can be produced in two ways. First as three files with 
# individual data (idata.txt), household data (hdata.txt) and macro data
# (mdata.txt). The second way creates a new folder containing one separate 
# ASCII file for each output variable.
#
# Author: Tomas Pettersson
#  - TP111118: Changed from data frames to data tables in order to reduce
#              runtimes.
#  - TP130617: Added dropvars argument
##############################################################################

#
# Args:
# - filepath: path to SESIM output files
# - headerfile: name of headerfile (the name of the data file is derived from this)
# - createASCII: indicates what type of ASCII data is to be created (e.g. for export
#     to SAS).
#	0) No ASCII output (default)
#	1) One file per variable (below denoted fragmented files). No identity numbers are 
#	   included in the files but since the order of all files (within the i_-, h_- or 
#	   m_-domains) are the same the files can be stacked by columns to create a merged 
#	   dataset.
#	2) All variables in the same file. Creates one file per domain; individual data in
#	   idata.txt, household data in hdata.txt and macro data in mdata.txt.
# - buildMatrix: indicates if a data frame is to be built. NOTE: if a large sample of 
#     SESIM is run for many years the matrix will probably not fit in memory!
# - echo: indicates if output is written to the log during run-time
# - selectobs: string containing valid selection to limit the observations written to the
#     idata data frame. EXAMPLE: to select only individuals living in Sweden set
#     selectobs = "i_abroad == 0".
#     NOTE: corresponding selections of hdata or mdata will have to be done manually.
#     NOTE2: no error handling is done - watch log for warnings...
# - dropvars: array of character strings containing names of variables to drop
#  - NOTE: operates only on individual variables
# - aggregate: list of calls to aggregate() in order to create aggregated data used for further 
#     analysis. Creates list of data frames, one per call. This is helpful in large data where 
#     the full data does not fit in memory. Aggregation only works on the individual dataset. 
#     Note that the year variable should be included as a by-variable in order to differentiate 
#     yearly data.

# debug(getSESIMdata)
# undebug(getSESIMdata)
#

library(data.table)

getSESIMdata <- function(headerfilename, filepath = "c:/SESIM/microdata/",
	createASCII = 0, buildMatrix = 1, echo = 1, selectobs = NULL, dropvars = NULL,
                         aggregate = NULL){

	### Change directory and read files
	setwd(filepath)
	headerfile <- read.delim(headerfilename, 	header = FALSE, sep = " ")
	binfilename <- gsub("header.txt", "data.bin", headerfilename)
	binfile <- file(binfilename , "rb")

	### Create output directory for fragmented files
	if (createASCII == 2) {
		dirname <- as.character(strsplit(headerfilename, ".txt"))
		if (file.exists(dirname) == F) dir.create(dirname)
		setwd(dirname)
	}

	### Calculate first and last year of output
	minyear <- min(headerfile$V1)
	maxyear <- max(headerfile$V1)

	### Calculate the number of individual, household and macro variables
	firstyear <- subset(headerfile, V1 == minyear)
	temp <- toupper(substr(as.character(firstyear$V2), 1, 1))
	nivars <- length(temp[temp == "I"])
	nhvars <- length(temp[temp == "H"])
	nmvars <- length(temp[temp == "M"])

	### Read variable names
	idx <- toupper(substr(as.character(firstyear$V2), 1, 1)) == "I"
	ivarnames <- as.character(firstyear$V2[idx])
	idx <- toupper(substr(as.character(firstyear$V2), 1, 1)) == "H"
	hvarnames <- as.character(firstyear$V2[idx])
	idx <- toupper(substr(as.character(firstyear$V2), 1, 1)) == "M"
	mvarnames <- as.character(firstyear$V2[idx])
	if (echo == 1){
		cat("Individual variables:\n")
      if (is.null(dropvars) == T){
         print(ivarnames)
      } else {
         print(setdiff(ivarnames, dropvars))
      }		
		cat("\n Household variables:\n")
		print(hvarnames)
		cat("\n Macro variables:\n")
		print(mvarnames)
		cat("\n\n")
	}

	### Compile variable types (individual, household or macro)
	vartypes <- toupper(substr(as.character(headerfile$V2), 1, 1))

	### Compile datatypes (long, integer, byte or double)
	datatypes <- toupper(substr(as.character(headerfile$V4), 1, 3))

	idata <- NULL
	hdata <- NULL
	mdata <- NULL
	aggdata <- NULL

	rowcounter = 1

	### Process each year...
	for (year in minyear:maxyear){

		idata_ <- NULL
		hdata_ <- NULL
		mdata_ <- NULL
		aggdata_ <- NULL

		yearfileswritten <- F

		if (echo == 1) cat("Current year:", year, "\n")
		flush.console()

		### Process each variable...
		for (var in 1:(nivars + nhvars + nmvars)){

			nobs <- headerfile$V3[rowcounter]
			
		    	### reading of data is conditioned on datatype
	    		data <- switch(datatypes[rowcounter],
		      		LON = readBin(binfile, integer(), nobs , size = 4),
		      		INT = readBin(binfile, integer(), nobs , size = 2),
		      		BYT = readBin(binfile, integer(), nobs , size = 1),
		      		DOU = readBin(binfile, double(), nobs , size = 8),
				SIN = readBin(binfile, double(), nobs, size = 4))

			vname <- as.character(headerfile[rowcounter, 2])

			### Output data frames are created
			if (vartypes[rowcounter] == "I"){				
				if (is.null(idata_) == T) idata_ <- data.table(year = rep(year, nobs))
            
            # Variable is added to data if not dropped
            if (length(grep(vname, dropvars)) == 0){
               idata_ <- cbind(idata_, data)
               setnames(idata_, "data", paste("v", rowcounter, sep = ""))        
            }
			}

			if (vartypes[rowcounter] == "H"){
				if (is.null(hdata_) == T) hdata_ <- data.table(year = rep(year, nobs))
				hdata_ <- cbind(hdata_, data)
				setnames(hdata_, "data", paste("v", rowcounter, sep = ""))        				
			}

			if (vartypes[rowcounter] == "M"){
				if (is.null(mdata_) == T) mdata_ <- data.table(year = rep(year, nobs))
				mdata_ <- cbind(mdata_, data)
				setnames(mdata_, "data", paste("v", rowcounter, sep = ""))        				
			}

			rowcounter = rowcounter + 1      

		} # end for

		if (is.null(idata_) == F){
         if (is.null(dropvars) == T){
            setnames(idata_, names(idata_), c("year", ivarnames))
         } else {
            setnames(idata_, names(idata_), c("year", setdiff(ivarnames, dropvars)))
         }
         
		}
		if (is.null(hdata_) == F) setnames(hdata_, names(hdata_), c("year", hvarnames))
		if (is.null(mdata_) == F) setnames(mdata_, names(mdata_), c("year", mvarnames))

		# execute selection of observations in idata_
		if (is.null(selectobs) == F & is.null(idata_) == F){
			str <- paste("idata_ <- subset(idata_, ", selectobs, ")", sep = "")
			err <- eval(parse(text = str))
		}

		# Create aggregate data
		if (is.null(aggregate) == F){
			str <- paste("aggdata_ <- with(idata_, aggregate(", aggregate, "))", sep = "")
			if (is.null(aggdata) == T){
				for (i2 in 1:length(aggregate)){
					err <- eval(parse(text = str[i2]))		
					aggdata_ <- data.table(aggdata_)
					aggdata[i2] <- list(aggdata_)
				}
			} else {
				for (i2 in 1:length(aggregate)){
					err <- eval(parse(text = str[i2]))		
					aggdata_ <- data.table(aggdata_)
					aggdata[[i2]] <- rbind(aggdata[[i2]], aggdata_)
				}
			}			
		}

		# Writing data to fragmented ASCII files
		if (createASCII == 2){

			# Year variables is created for fragmented files output
			if (year == minyear){
				write.table("i_year", "i_year.txt", row.names = F, col.names = F, 
					quote = F)
				write.table("h_year", "h_year.txt", row.names = F, col.names = F, 
					quote = F)
				write.table("m_year", "m_year.txt", row.names = F, col.names = F, 
					quote = F)
			}		
			if (is.null(idata_) == F){
				write.table(rep(year, dim(idata_)[1]), "i_year.txt", row.names = F, 
					append = T, col.names = F)			
				if (year == minyear){
					for (c in 1:ncol(idata_)){
						if (colnames(idata_)[c] != "year"){
							fname <- paste(colnames(idata_)[c], ".txt", sep = "")
							write.table(colnames(idata_)[c], fname, row.names = F, 
								append = F, col.names = F, quote = F)
							write.table(idata_[, c], fname, row.names = F, append = T, 
								col.names = F, quote = F)
						}
					}
				} else {
					for (c in 1:ncol(idata_)){
						if (colnames(idata_)[c] != "year"){
							fname <- paste(colnames(idata_)[c], ".txt", sep = "")
							write.table(idata_[, c], fname, row.names = F, append = T, 
								col.names = F)
						}
					}
				}
			}
			if (is.null(hdata_) == F){
				write.table(rep(year, dim(hdata_)[1]), "h_year.txt", row.names = F, 
					append = T, col.names = F)			
				if (year == minyear){
					for (c in 1:ncol(hdata_)){
						if (colnames(hdata_)[c] != "year"){
							fname <- paste(colnames(hdata_)[c], ".txt", sep = "")
							write.table(colnames(hdata_)[c], fname, row.names = F, 
								append = F, col.names = F, quote = F)
							write.table(hdata_[, c], fname, row.names = F, append = T, 
								col.names = F, quote = F)
						}
					}
				} else {
					for (c in 1:ncol(hdata_)){
						if (colnames(hdata_)[c] != "year"){
							fname <- paste(colnames(hdata_)[c], ".txt", sep = "")
							write.table(hdata_[, c], fname, row.names = F, append = T, 
								col.names = F)
						}
					}
				}
			}

			if (is.null(mdata_) == F){
				write.table(rep(year, dim(mdata_)[1]), "m_year.txt", row.names = F, 
					append = T, col.names = F)			
				if (year == minyear){
					for (c in 1:ncol(mdata_)){
						if (colnames(mdata_)[c] != "year"){
							fname <- paste(colnames(mdata_)[c], ".txt", sep = "")
							write.table(colnames(mdata_)[c], fname, row.names = F, 
								append = F, col.names = F, quote = F)
							write.table(mdata_[, c], fname, row.names = F, append = T, 
								col.names = F, quote = F)
						}
					}
				} else {
					for (c in 1:ncol(mdata_)){
						if (colnames(mdata_)[c] != "year"){
							fname <- paste(colnames(mdata_)[c], ".txt", sep = "")
							write.table(mdata_[, c], fname, row.names = F, append = T, 
								col.names = F)
						}
					}
				}

			}
		}

		# Data frames are created
		if (buildMatrix == 1){
			if (nivars > 0){
				if (is.null(idata)) 
					idata <- idata_
				else 
					idata <- rbind(idata, idata_)
			}

			if (nhvars > 0){
				if (is.null(hdata)) 
					hdata <- hdata_
				else 
					hdata <- rbind(hdata, hdata_)
			}

			if (nmvars > 0){
				if (is.null(mdata)) 
					mdata <- mdata_
				else 
					mdata <- rbind(mdata, mdata_)		
			}
		}

		### Create ASCII data output
		if (createASCII == 1){

			### If first year headers and data are written to file
			if (year == minyear){
				if (nivars > 0) {
					write.table(t(colnames(idata_)), file = "idata.txt", row.names = F, 
						col.names = F, quote = F)
					write.table(idata_, file = "idata.txt", row.names = F, 
						col.names = F, quote = F, append = T)
				}

				if (nhvars > 0){
					write.table(t(colnames(hdata_)), file = "hdata.txt", row.names = F, 
						col.names = F, quote = F)
					write.table(hdata_, file = "hdata.txt", row.names = F, 
						col.names = F, quote = F, append = T)
				}

				if (nmvars > 0){
					write.table(t(colnames(mdata_)), file = "mdata.txt", row.names = F, 
						col.names = F, quote = F)
					write.table(mdata_, file = "mdata.txt", row.names = F, 
						col.names = F, quote = F, append = T)
				}

			}else{
				### The following years only data is written
				if (nivars > 0) write.table(idata_, file = "idata.txt", 
					row.names = F, col.names = F, quote = F, append = T)

				if (nhvars > 0) write.table(hdata_, file = "hdata.txt", 
					row.names = F, col.names = F, quote = F, append = T)

				if (nmvars > 0) write.table(mdata_, file = "mdata.txt", 
					row.names = F, col.names = F, quote = F, append = T)
			}
		}
	}
	close(binfile)

	return(list(idata = idata, hdata = hdata, mdata = mdata, aggdata = aggdata))
}

# Examples of calls to the function...
#
# Sdat <- getSESIMdata("YYMMDD_HHMMSS_header.txt")
#
# Sdat <- getSESIMdata("YYMMDD_HHMMSS_header.txt", createASCII = F)
#
# Sdat <- getSESIMdata(filepath = "c:/sesim/microdata", "YYMMDD_HHMMSS_header.txt", 
#	buildMatrix = F)
#
# Sdat <- getSESIMdata("YYMMDD_HHMMSS_header.txt", createASCII = 2, buildMatrix = 0)
#
# Sdat <- getSESIMdata("YYMMDD_HHMMSS_header.txt", 
#	selectobs = "i_abroad == 0 & i_age >= 16 & i_age <= 64")
#
# Sdat <- getSESIMdata("YYMMDD_HHMMSS_header.txt", 
#	aggregate <- c("i_dead, list(year = year, sex = i_sex, age = i_age), mean",
#	               "i_deathprobs, list(year = year, sex = i_sex, age = i_age), mean"))
#
# Sdat <- getSESIMdata("YYMMDD_HHMMSS_header.txt", dropvars = c("i_age", "i_sex"))

